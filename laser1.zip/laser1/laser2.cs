﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laser1
{
    public partial class laser2 : Form
    {
        public laser2()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Laser1 f1 = new Laser1(); //this is the change, code for redirect  
            f1.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            laser5 f5 = new laser5 (); //this is the change, code for redirect  
            f5.ShowDialog();
        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void customerBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customerBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.customersWorkers);

        }

        private void laser2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customersWorkers.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.customersWorkers.Customer);

        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {

        }
    }
}
