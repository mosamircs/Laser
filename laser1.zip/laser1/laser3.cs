﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laser1
{
    public partial class laser3 : Form
    {
        public laser3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Laser1 f1 = new Laser1(); //this is the change, code for redirect  
            f1.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            laser4 f4 = new laser4(); //this is the change, code for redirect  
            f4.ShowDialog();
        }

        private void workerBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.workerBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.customersWorkers);

        }

        private void laser3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customersWorkers.Worker' table. You can move, or remove it, as needed.
            this.workerTableAdapter.Fill(this.customersWorkers.Worker);

        }
    }
}
