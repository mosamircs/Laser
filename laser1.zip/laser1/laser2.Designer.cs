﻿namespace laser1
{
    partial class laser2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(laser2));
            System.Windows.Forms.Label customerIDLabel;
            System.Windows.Forms.Label customerNameLabel;
            System.Windows.Forms.Label phoneLabel;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label orderStartLabel;
            System.Windows.Forms.Label ordertimeLabel;
            System.Windows.Forms.Label orderEndLabel;
            System.Windows.Forms.Label theOrderLabel;
            System.Windows.Forms.Label dastaNumberLabel;
            System.Windows.Forms.Label customer7SabLabel;
            System.Windows.Forms.Label customer7SabKademLabel;
            this.customersWorkers = new laser1.customersWorkers();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customerTableAdapter = new laser1.customersWorkersTableAdapters.CustomerTableAdapter();
            this.tableAdapterManager = new laser1.customersWorkersTableAdapters.TableAdapterManager();
            this.customerBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.customerBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.customerIDTextBox = new System.Windows.Forms.TextBox();
            this.customerNameTextBox = new System.Windows.Forms.TextBox();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.orderStartDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.ordertimeTextBox = new System.Windows.Forms.TextBox();
            this.orderEndDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.theOrderTextBox = new System.Windows.Forms.TextBox();
            this.dastaNumberTextBox = new System.Windows.Forms.TextBox();
            this.customer7SabTextBox = new System.Windows.Forms.TextBox();
            this.customer7SabKademTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            customerIDLabel = new System.Windows.Forms.Label();
            customerNameLabel = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            orderStartLabel = new System.Windows.Forms.Label();
            ordertimeLabel = new System.Windows.Forms.Label();
            orderEndLabel = new System.Windows.Forms.Label();
            theOrderLabel = new System.Windows.Forms.Label();
            dastaNumberLabel = new System.Windows.Forms.Label();
            customer7SabLabel = new System.Windows.Forms.Label();
            customer7SabKademLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.customersWorkers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingNavigator)).BeginInit();
            this.customerBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // customersWorkers
            // 
            this.customersWorkers.DataSetName = "customersWorkers";
            this.customersWorkers.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            this.customerBindingSource.DataSource = this.customersWorkers;
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CustomerTableAdapter = this.customerTableAdapter;
            this.tableAdapterManager.UpdateOrder = laser1.customersWorkersTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.WorkerTableAdapter = null;
            // 
            // customerBindingNavigator
            // 
            this.customerBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.customerBindingNavigator.BindingSource = this.customerBindingSource;
            this.customerBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.customerBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.customerBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.customerBindingNavigatorSaveItem});
            this.customerBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.customerBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.customerBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.customerBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.customerBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.customerBindingNavigator.Name = "customerBindingNavigator";
            this.customerBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.customerBindingNavigator.Size = new System.Drawing.Size(436, 25);
            this.customerBindingNavigator.TabIndex = 0;
            this.customerBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // customerBindingNavigatorSaveItem
            // 
            this.customerBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.customerBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("customerBindingNavigatorSaveItem.Image")));
            this.customerBindingNavigatorSaveItem.Name = "customerBindingNavigatorSaveItem";
            this.customerBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.customerBindingNavigatorSaveItem.Text = "Save Data";
            this.customerBindingNavigatorSaveItem.Click += new System.EventHandler(this.customerBindingNavigatorSaveItem_Click);
            // 
            // customerIDLabel
            // 
            customerIDLabel.AutoSize = true;
            customerIDLabel.Location = new System.Drawing.Point(46, 61);
            customerIDLabel.Name = "customerIDLabel";
            customerIDLabel.Size = new System.Drawing.Size(68, 13);
            customerIDLabel.TabIndex = 1;
            customerIDLabel.Text = "Customer ID:";
            // 
            // customerIDTextBox
            // 
            this.customerIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "CustomerID", true));
            this.customerIDTextBox.Location = new System.Drawing.Point(166, 58);
            this.customerIDTextBox.Name = "customerIDTextBox";
            this.customerIDTextBox.Size = new System.Drawing.Size(200, 20);
            this.customerIDTextBox.TabIndex = 2;
            // 
            // customerNameLabel
            // 
            customerNameLabel.AutoSize = true;
            customerNameLabel.Location = new System.Drawing.Point(46, 87);
            customerNameLabel.Name = "customerNameLabel";
            customerNameLabel.Size = new System.Drawing.Size(85, 13);
            customerNameLabel.TabIndex = 3;
            customerNameLabel.Text = "Customer Name:";
            // 
            // customerNameTextBox
            // 
            this.customerNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "CustomerName", true));
            this.customerNameTextBox.Location = new System.Drawing.Point(166, 84);
            this.customerNameTextBox.Name = "customerNameTextBox";
            this.customerNameTextBox.Size = new System.Drawing.Size(200, 20);
            this.customerNameTextBox.TabIndex = 4;
            // 
            // phoneLabel
            // 
            phoneLabel.AutoSize = true;
            phoneLabel.Location = new System.Drawing.Point(46, 113);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(41, 13);
            phoneLabel.TabIndex = 5;
            phoneLabel.Text = "Phone:";
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "Phone", true));
            this.phoneTextBox.Location = new System.Drawing.Point(166, 110);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(200, 20);
            this.phoneTextBox.TabIndex = 6;
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.Location = new System.Drawing.Point(46, 139);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(47, 13);
            addressLabel.TabIndex = 7;
            addressLabel.Text = "address:";
            // 
            // addressTextBox
            // 
            this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "address", true));
            this.addressTextBox.Location = new System.Drawing.Point(166, 136);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(200, 20);
            this.addressTextBox.TabIndex = 8;
            // 
            // orderStartLabel
            // 
            orderStartLabel.AutoSize = true;
            orderStartLabel.Location = new System.Drawing.Point(46, 166);
            orderStartLabel.Name = "orderStartLabel";
            orderStartLabel.Size = new System.Drawing.Size(59, 13);
            orderStartLabel.TabIndex = 9;
            orderStartLabel.Text = "order Start:";
            // 
            // orderStartDateTimePicker
            // 
            this.orderStartDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.customerBindingSource, "orderStart", true));
            this.orderStartDateTimePicker.Location = new System.Drawing.Point(166, 162);
            this.orderStartDateTimePicker.Name = "orderStartDateTimePicker";
            this.orderStartDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.orderStartDateTimePicker.TabIndex = 10;
            // 
            // ordertimeLabel
            // 
            ordertimeLabel.AutoSize = true;
            ordertimeLabel.Location = new System.Drawing.Point(46, 191);
            ordertimeLabel.Name = "ordertimeLabel";
            ordertimeLabel.Size = new System.Drawing.Size(53, 13);
            ordertimeLabel.TabIndex = 11;
            ordertimeLabel.Text = "ordertime:";
            // 
            // ordertimeTextBox
            // 
            this.ordertimeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "ordertime", true));
            this.ordertimeTextBox.Location = new System.Drawing.Point(166, 188);
            this.ordertimeTextBox.Name = "ordertimeTextBox";
            this.ordertimeTextBox.Size = new System.Drawing.Size(200, 20);
            this.ordertimeTextBox.TabIndex = 12;
            // 
            // orderEndLabel
            // 
            orderEndLabel.AutoSize = true;
            orderEndLabel.Location = new System.Drawing.Point(46, 218);
            orderEndLabel.Name = "orderEndLabel";
            orderEndLabel.Size = new System.Drawing.Size(56, 13);
            orderEndLabel.TabIndex = 13;
            orderEndLabel.Text = "order End:";
            // 
            // orderEndDateTimePicker
            // 
            this.orderEndDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.customerBindingSource, "orderEnd", true));
            this.orderEndDateTimePicker.Location = new System.Drawing.Point(166, 214);
            this.orderEndDateTimePicker.Name = "orderEndDateTimePicker";
            this.orderEndDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.orderEndDateTimePicker.TabIndex = 14;
            // 
            // theOrderLabel
            // 
            theOrderLabel.AutoSize = true;
            theOrderLabel.Location = new System.Drawing.Point(46, 243);
            theOrderLabel.Name = "theOrderLabel";
            theOrderLabel.Size = new System.Drawing.Size(54, 13);
            theOrderLabel.TabIndex = 15;
            theOrderLabel.Text = "the Order:";
            // 
            // theOrderTextBox
            // 
            this.theOrderTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "theOrder", true));
            this.theOrderTextBox.Location = new System.Drawing.Point(166, 240);
            this.theOrderTextBox.Name = "theOrderTextBox";
            this.theOrderTextBox.Size = new System.Drawing.Size(200, 20);
            this.theOrderTextBox.TabIndex = 16;
            // 
            // dastaNumberLabel
            // 
            dastaNumberLabel.AutoSize = true;
            dastaNumberLabel.Location = new System.Drawing.Point(46, 269);
            dastaNumberLabel.Name = "dastaNumberLabel";
            dastaNumberLabel.Size = new System.Drawing.Size(76, 13);
            dastaNumberLabel.TabIndex = 17;
            dastaNumberLabel.Text = "dasta Number:";
            // 
            // dastaNumberTextBox
            // 
            this.dastaNumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "dastaNumber", true));
            this.dastaNumberTextBox.Location = new System.Drawing.Point(166, 266);
            this.dastaNumberTextBox.Name = "dastaNumberTextBox";
            this.dastaNumberTextBox.Size = new System.Drawing.Size(200, 20);
            this.dastaNumberTextBox.TabIndex = 18;
            // 
            // customer7SabLabel
            // 
            customer7SabLabel.AutoSize = true;
            customer7SabLabel.Location = new System.Drawing.Point(46, 295);
            customer7SabLabel.Name = "customer7SabLabel";
            customer7SabLabel.Size = new System.Drawing.Size(78, 13);
            customer7SabLabel.TabIndex = 19;
            customer7SabLabel.Text = "customer7Sab:";
            // 
            // customer7SabTextBox
            // 
            this.customer7SabTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "customer7Sab", true));
            this.customer7SabTextBox.Location = new System.Drawing.Point(166, 292);
            this.customer7SabTextBox.Name = "customer7SabTextBox";
            this.customer7SabTextBox.Size = new System.Drawing.Size(200, 20);
            this.customer7SabTextBox.TabIndex = 20;
            // 
            // customer7SabKademLabel
            // 
            customer7SabKademLabel.AutoSize = true;
            customer7SabKademLabel.Location = new System.Drawing.Point(46, 321);
            customer7SabKademLabel.Name = "customer7SabKademLabel";
            customer7SabKademLabel.Size = new System.Drawing.Size(114, 13);
            customer7SabKademLabel.TabIndex = 21;
            customer7SabKademLabel.Text = "customer7Sab Kadem:";
            // 
            // customer7SabKademTextBox
            // 
            this.customer7SabKademTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "customer7SabKadem", true));
            this.customer7SabKademTextBox.Location = new System.Drawing.Point(166, 318);
            this.customer7SabKademTextBox.Name = "customer7SabKademTextBox";
            this.customer7SabKademTextBox.Size = new System.Drawing.Size(200, 20);
            this.customer7SabKademTextBox.TabIndex = 22;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(166, 385);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 23);
            this.button1.TabIndex = 23;
            this.button1.Text = "Register Customer";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // laser2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 455);
            this.Controls.Add(this.button1);
            this.Controls.Add(customerIDLabel);
            this.Controls.Add(this.customerIDTextBox);
            this.Controls.Add(customerNameLabel);
            this.Controls.Add(this.customerNameTextBox);
            this.Controls.Add(phoneLabel);
            this.Controls.Add(this.phoneTextBox);
            this.Controls.Add(addressLabel);
            this.Controls.Add(this.addressTextBox);
            this.Controls.Add(orderStartLabel);
            this.Controls.Add(this.orderStartDateTimePicker);
            this.Controls.Add(ordertimeLabel);
            this.Controls.Add(this.ordertimeTextBox);
            this.Controls.Add(orderEndLabel);
            this.Controls.Add(this.orderEndDateTimePicker);
            this.Controls.Add(theOrderLabel);
            this.Controls.Add(this.theOrderTextBox);
            this.Controls.Add(dastaNumberLabel);
            this.Controls.Add(this.dastaNumberTextBox);
            this.Controls.Add(customer7SabLabel);
            this.Controls.Add(this.customer7SabTextBox);
            this.Controls.Add(customer7SabKademLabel);
            this.Controls.Add(this.customer7SabKademTextBox);
            this.Controls.Add(this.customerBindingNavigator);
            this.Name = "laser2";
            this.Text = " الزباين";
            this.Load += new System.EventHandler(this.laser2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customersWorkers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingNavigator)).EndInit();
            this.customerBindingNavigator.ResumeLayout(false);
            this.customerBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private customersWorkers customersWorkers;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private customersWorkersTableAdapters.CustomerTableAdapter customerTableAdapter;
        private customersWorkersTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator customerBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton customerBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox customerIDTextBox;
        private System.Windows.Forms.TextBox customerNameTextBox;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.DateTimePicker orderStartDateTimePicker;
        private System.Windows.Forms.TextBox ordertimeTextBox;
        private System.Windows.Forms.DateTimePicker orderEndDateTimePicker;
        private System.Windows.Forms.TextBox theOrderTextBox;
        private System.Windows.Forms.TextBox dastaNumberTextBox;
        private System.Windows.Forms.TextBox customer7SabTextBox;
        private System.Windows.Forms.TextBox customer7SabKademTextBox;
        private System.Windows.Forms.Button button1;
    }
}