﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laser1
{
    public partial class laser5 : Form
    {
        public laser5()
        {
            InitializeComponent();
        }

        private void workerBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.workerBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.customersWorkers);

        }

        private void laser5_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customersWorkers.Worker' table. You can move, or remove it, as needed.
            this.workerTableAdapter.Fill(this.customersWorkers.Worker);

        }
    }
}
