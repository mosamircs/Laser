﻿CREATE TABLE [dbo].[customer]
(
	[Id] BIGINT NOT NULL PRIMARY KEY, 
    [name] NVARCHAR(100) NOT NULL, 
    [phoneNumber] NCHAR(12) NOT NULL, 
    [address] NVARCHAR(100) NOT NULL, 
    [orderTime] DATE NOT NULL, 
    [periodOfWork] INT NOT NULL, 
    [endTime] DATE NOT NULL, 
    [theOrder] NVARCHAR(1000) NOT NULL, 
   
)
